#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LinkedList.h"


char* GetFileName(char* in)
{
    int len = strlen(in);
    char* name = (char*)calloc(len+1,sizeof(char));
    strcpy(name,in);
    len = strlen(name);
    name[len-4] = 'l';
    name[len-3] = 'a';
    name[len-2] = 'd';
    name[len-1] = 'j';
    return name;
}

void addValuetoNode(int aux_1, int aux_2, int val, LinkedList *L){
    LinkedList* list_p=L, *help_me = NULL;
    int j=0;
    j=aux_1;
        while(j>0){
            list_p = getNextNodeLinkedList(list_p);
            j--;
        }
        
        help_me = getItemLinkedList(list_p);
        if (help_me==NULL)
            help_me= initLinkedList();
        
        int* new=(int*) malloc(2*sizeof(int));
        new[0]=aux_2;
        new[1]=val;
        help_me = insertUnsortedLinkedList(help_me, (Item) new );
}

void freeEntryItem(Item item)
{
    return;       /* no mem actually allocated */
}


/*
 * Function:
 *   main
 */
int main(int argc, char* argv[])
{
    LinkedList* L = initLinkedList();
    int i, V, E;
    FILE *fp = NULL, *out = NULL;
    char* outfilename = GetFileName(argv[1]);

    if (argc < 2)
    {
        fprintf(stderr,"No file evoced.\n");
        exit(1);
    }
    fp = fopen(argv[1],"r+");
    if (fp == NULL)
    {
        fprintf(stderr,"Couldn't open file.\n");
        exit(1);
    }


    fscanf(fp,"%d %d ",&V, &E); //Get number of Vertices and Edges


    /* create lists */
    for (i=0; i<V; i++)
    {
        L = insertUnsortedLinkedList(L, (Item) NULL);
    }

    int aux_y, aux_x, val;
    for (i = 0; i < E; i++)
    {
        fscanf(fp,"%d %d %d ",&aux_x,&aux_y,&val);
        addValuetoNode(aux_x, aux_y, val,L);
        addValuetoNode(aux_y, aux_x, val,L);
    }
    /* print out lists */
    
    out = fopen(outfilename,"w+");
    if (out == NULL)
    {
        fprintf(stderr,"Couldn't open file.\n");
        exit(1);
    }
    fprintf(out, "%d\n", V);
    for(i=0; i<V; i++){
        LinkedList* help_me=NULL, *help_me_too=NULL;
        Item *and_me=NULL;
        help_me=L;
        while(help_me!=NULL){
            
            help_me_too= (LinkedList*) getItemLinkedList(help_me);
            
            while(help_me_too!=NULL) {
            
                and_me= (int**)getItemLinkedList(help_me_too);
                fprintf(out,"%d:%d ", ((int*)and_me)[0], ((int*)and_me)[1]);
                help_me_too=getNextNodeLinkedList(help_me_too);
            }
            fprintf(out,"%d\n", -1);
            help_me=getNextNodeLinkedList(help_me);
        }
        
    }
    fclose(out);
    fclose(fp);
    

LinkedList* aux = L;
    while(aux != NULL)
    {
        LinkedList* aux2 = aux;
        while (aux2 != NULL)
        {
            i = *((int *) getItemLinkedList(aux));
            printf ("item = %d \n",  i);
            aux2 = getNextNodeLinkedList(aux2);
        }
        aux = getNextNodeLinkedList(aux);
        printf("\n");
    }

    /* Free linked lists with entries  
    LinkedList *aux = L;
    for (i = 0; i < E; i++){
        aux = getNextNodeLinkedList(L);
            freeLinkedList(L,freeEntryItem);
        L = aux;
    }*/
    freeLinkedList(L, freeEntryItem);


    return 0;
}
