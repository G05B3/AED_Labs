
// A C Program to demonstrate adjacency list
// representation of graphs
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>


// A structure to represent an adjacency list node
typedef struct AdjListNode
{
    int dest;
    int val;
    struct AdjListNode *next;
}AdjListNode;

// A structure to represent an adjacency list
typedef struct AdjList
{
    struct AdjListNode *head;
}AdjList;

// A structure to represent a graph. A graph
// is an array of adjacency lists.
// Size of array will be V (number of vertices
// in graph)
typedef struct Graph
{
    int V;
    struct AdjList *array;
} Graph;

// A utility function to create a new adjacency list node
AdjListNode *newAdjListNode(int dest, int val)
{
    AdjListNode *newNode =
        (AdjListNode *)malloc(sizeof(AdjListNode));
    newNode->dest = dest;
    newNode->val = val;
    newNode->next = NULL;
    return newNode;
}

// A utility function that creates a graph of V vertices
Graph *createGraph(int V)
{
    Graph *graph =
        (Graph *)malloc(sizeof(Graph));
    graph->V = V;

    // Create an array of adjacency lists.  Size of
    // array will be V
    graph->array =
        (AdjList *)malloc(V * sizeof(AdjList));

    // Initialize each adjacency list as empty by
    // making head as NULL
    int i;
    for (i = 0; i < V; ++i)
        graph->array[i].head = NULL;

    return graph;
}

void add_edge(Graph *graph, int src, int dest, int val){
    // Add an edge from src to dest.  A new node is
    // added to the adjacency list of src.  The node
    // is added at the beginning
    AdjListNode *newNode = newAdjListNode(dest, val);
    newNode->next = graph->array[src].head;
    graph->array[src].head = newNode;
}

// Adds an edge to an undirected graph
void addEdges(Graph *graph, int src, int dest, int val)
{
    //It needs to add two edges, one to the source one to the destiny
    add_edge(graph, src, dest, val);
    add_edge(graph, dest, src, val);
}

// A utility function to print the adjacency list
// representation of graph
void printGraph(Graph *graph, FILE *out)
{
    int v;
    for (v = 0; v < graph->V; ++v)
    {
        AdjListNode *pCrawl = graph->array[v].head;
        while (pCrawl)
        {
            fprintf(out,"%d:%d ", pCrawl->dest, pCrawl->val);
            pCrawl = pCrawl->next;
        }
        fprintf(out,"-1\n");
    }
}