#ifndef ADJLIST_H
#define ADJLIST_H

#include <stdio.h>

// A structure to represent an adjacency list node
typedef struct AdjListNode AdjListNode;

// A structure to represent an adjacency list
typedef struct AdjList AdjList;

typedef struct Graph Graph;

AdjListNode *newAdjListNode(int dest, int val);
Graph *createGraph(int V);
void add_edge(Graph *graph, int src, int dest, int val);
void addEdges(Graph *graph, int src, int dest, int val);
void printGraph(Graph *graph, FILE* out);

#endif
