/*  Quick test for List package, namely insert* functions
 *  Last change abl 2019.03.21
 */



/* Header Inclusions                                              */
#include<stdio.h>
#include<stdlib.h>
#include<string.h>


char* GetFileName(char* in)
{
    int len = strlen(in);
    char* name = (char*)calloc(len+2,sizeof(char));
    strcpy(name,in);
    len = strlen(name);
    name[len-3] = 'e';
    name[len-2] = 'd';
    name[len-1] = 'g';
    name[len] = 'e';
    return name;
}

void free_m(int** m, int N){

    int i;

    for (i = 0; i < N; i++)
        free(m[i]);
    free(m);

}

void m_prt(int** m, int N){
    
    int i, j;

    for (i = 0;i < N; i++){
        for (j = 0; j < N; j++)
                printf("%d ",m[i][j]);  
        printf("\n");
    }
}

int** m_init(int N){

    int** new_m = NULL, i;

    new_m = (int**)calloc(N,sizeof(int*));
    if (new_m == NULL)
    {
        fprintf(stderr,"Mem Error.\n");
        exit(1);
    }
    for (i = 0; i < N; i++){
        new_m[i] = (int*)calloc(N,sizeof(int));
        if (new_m[i] == NULL)
        {
            fprintf(stderr,"Mem Error.\n");
            exit(1);
        }
    }

    return new_m;
}

/*
 * Function:
 *   main
 */
int main(int argc, char *argv[])
{
  
    int **matrix = NULL, i, j, V = 0, E = 0, gmax=0; //V = nº de vértices, E = nº de arestas
    FILE *fp = NULL, *out = NULL;
    
    if (argc < 2)
    {
        fprintf(stderr,"No file evoced.\n");
        exit(1);
    }
    fp = fopen(argv[1],"r+");
    if (fp == NULL)
    {
        fprintf(stderr,"Couldn't open file.\n");
        exit(1);
    }

    fscanf(fp,"%d",&V);
    matrix = m_init(V);

    for (i = 0; i < V; i++)
        for (j = 0; j < V; j++){
            fscanf(fp,"%d ",&matrix[i][j]);
            if (matrix[i][j] > 0 && i < j) //se houver uma aresta
            E++;
        }
    
    //float densidade = E / (V*(V-1)/2); //densidade do grafo = Edges / Edges do grafo completo (V*(V-1)/2)
      float densidade = 2*E/(float)V;

    char* outfilename;

    outfilename = GetFileName(argv[1]);
    out = fopen(outfilename,"w+");

 
    fprintf(out, "%d %d\n", V, E);
    
    for (i = 0; i < V; i++){
        int cnt=0;
        for (j = 0; j < V; j++){
            if (matrix[i][j] >0){
            if(i<j)
                fprintf(out, "%d %d %d\n", i, j, matrix[i][j]);
            cnt++;
            }
        }
        if (cnt>gmax)
        gmax=cnt;
    }
    m_prt(matrix,V);

    printf("\nA densidade do grafo é %lf.",densidade);
    printf("\nO grau máximo do grafo é %d.\n",gmax);
    
    
    
    fclose(fp);
    free_m(matrix,V);

    return 0;
}
