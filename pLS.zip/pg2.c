#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Adjlist.h"

char* GetFileName(char* in)
{
    int len = strlen(in);
    char* name = (char*)calloc(len+1,sizeof(char));
    strcpy(name,in);
    len = strlen(name);
    name[len-4] = 'l';
    name[len-3] = 'a';
    name[len-2] = 'd';
    name[len-1] = 'j';
    return name;
}

/*
 * Function:
 *   main
 */
int main(int argc, char* argv[])
{
    
    int i, V, E;
    FILE *fp = NULL, *out = NULL;
    char* outfilename = GetFileName(argv[1]);

    if (argc < 2)
    {
        fprintf(stderr,"No file evoced.\n");
        exit(1);
    }
    fp = fopen(argv[1],"r+");
    if (fp == NULL)
    {
        fprintf(stderr,"Couldn't open file.\n");
        exit(1);
    }


    fscanf(fp,"%d %d ",&V, &E); //Get number of Vertices and Edges
    Graph* LAdj = createGraph(V);


    int src, dest, val;
    for (i = 0; i < E; i++)
    {
        fscanf(fp,"%d %d %d ",&src,&dest,&val);
        addEdges(LAdj,src,dest,val);

    }

    out = fopen(outfilename,"w+");
    if (out == NULL)
    {
        fprintf(stderr,"Couldn't open file.\n");
        exit(1);
    }

    /* print out lists */
    fprintf(out,"%d\n",V);
    printGraph(LAdj,out);
   
    fclose(out);
    fclose(fp);

    return 0;
}
